Fmovies-plugin-bundle

Fmovies site plugin

About

This is a plugin that creates a new channel in Plex Media Server to view content indexed by the website FMovies.to.

Note: The author of this plugin has no affiliation with FMovies.to or the owners of the content that it indexes.

System Requirements

Plex Media Server:

Tested Working: Windows Mac OSX Linux
Plex Clients:

Tested Working:

Plex Home Theater
Plex/Web
Android
Chromecast
Ouya
Roku
iOS
PlexConnect
Smart TV
Not Tested:

Windows 8
Xbox
Windows Phone
How To Install

Download the latest version of the plugin.

Unzip and rename folder to "FMovies.bundle"

Copy FMovies.bundle into the PMS plugins directory under your user account:

Windows 7, Vista, or Server 2008: C:\Users[Your Username]\AppData\Local\Plex Media Server\Plug-ins

Windows XP, Server 2003, or Home Server: C:\Documents and Settings[Your Username]\Local Settings\Application Data\Plex Media

Server\Plug-ins

Mac/Linux: ~/Library/Application Support/Plex Media Server/Plug-ins

Restart PMS

Known Issues

No item summaries. No metadata info on final video page due to Google Video link. Source website has missing videos for some TV series.

Changelog

0.01 - 10/25/2016 - Intial Release

Donate

Like my work? Comment or buy me a coffee =) BTC:

1MmwvmDdSPe27MPAJxRaDQ3x3bMu855ayY

bitcoinate